package com.example.alumnibook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FirstTimeLogin extends AppCompatActivity {

    private ViewPager mSlideViewPager;
    private LinearLayout mDotsLayout;
    private SliderAdapter sliderAdapter;
    private TextView mDots[];
    private Button Register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_login);
        mSlideViewPager=findViewById(R.id.slideViewPager);
        mDotsLayout=findViewById(R.id.dotsLayout);
        Register=findViewById(R.id.RegisterButton);
        Register.setEnabled(false);


        sliderAdapter=new SliderAdapter(this);
        mSlideViewPager.setAdapter(sliderAdapter);


        addDotsIndicator(0);
        mSlideViewPager.addOnPageChangeListener(viewListener);
    }
    public void addDotsIndicator(int pos) {
        mDots=new TextView[3];
        mDotsLayout.removeAllViews();
        for(int i=0;i<3;i++) {
            mDots[i]=new TextView(this);
            mDots[i].setText(Html.fromHtml("&#8226"));
            mDots[i].setTextSize(35);
            mDots[i].setTextColor(getResources().getColor(R.color.colorTransparentWhite));
            mDotsLayout.addView(mDots[i]);
        }
        mDots[pos].setTextColor(getResources().getColor(R.color.colorWhite));
    }
    ViewPager.OnPageChangeListener viewListener=new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
              addDotsIndicator(position);
              if(position==2) {
                  Register.setEnabled(true);
                  Register.animate().alpha(1).setDuration(1000);
              }

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };
}
