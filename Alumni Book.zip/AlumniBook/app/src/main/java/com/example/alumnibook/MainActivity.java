package com.example.alumnibook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout layout;
    private ConstraintSet set0=new ConstraintSet();
    private ConstraintSet set1=new ConstraintSet();
    private ConstraintSet set2=new ConstraintSet();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent in=new Intent(this,FirstTimeLogin.class);
        startActivity(in);
        inflation();
        layout=findViewById(R.id.layout);
        set0.clone(layout);
        set1.clone(this,R.layout.menu_layout1);
        set2.clone(this,R.layout.portal_layout2);
        menuO=0;
        layout.setOnTouchListener(new OnSwipeTouchListener(MainActivity.this){
            public void onSwipeTop() { }

            public void onSwipeRight() { }
            public void onSwipeLeft() {
                if(menuO==1) { menuO=0; applyHome(); }
            }
            public void onSwipeBottom() { }
        });
    }
    private int menuO;
    public void applySet1() { menuO=1;  TransitionManager.beginDelayedTransition(layout); set1.applyTo((layout)); }
    public void applyHome() {  TransitionManager.beginDelayedTransition(layout); set0.applyTo((layout)); }
    public void applySet2() { Transition cB=new ChangeBounds(); cB.setInterpolator(new OvershootInterpolator()); TransitionManager.beginDelayedTransition(layout,cB); set2.applyTo((layout)); }
    public void menuOn(View v) {
        applySet1();

    }
    public void homeOn(View v) {
        applyHome();
        ImageView home=findViewById(R.id.homIcon1);
        ImageView friends=findViewById(R.id.connIcon1);
        home.setBackgroundColor(Color.argb(100,20,156,247));
        friends.setBackgroundColor(Color.WHITE);
    }
    public void peopleOn(View v) {
        applySet2();
    }

   public void inflation() {
        LinearLayout Horiz1=findViewById(R.id.linHorizScroll1);
        LayoutInflater inf=getLayoutInflater();
        Horiz1.removeAllViews();

        for(int i=0;i<11;i++) {
            View NoticeView1=inf.inflate(R.layout.noitice_layout1,null);
            TextView txt=NoticeView1.findViewById(R.id.txtViewNoticeLay1);
            txt.setText("Clg"+(i+1));
            Horiz1.addView(NoticeView1);
        }


        LinearLayout postBtw=findViewById(R.id.linPostBetw1), postAfter=findViewById(R.id.linPostAfter1);
        postBtw.removeAllViews(); postAfter.removeAllViews();
        View postBtwView=inf.inflate(R.layout.post_layout1,null);
        postBtw.addView(postBtwView);
        for(int i=2;i<12;i++) {
            View postAfterView=inf.inflate(R.layout.post_layout1,null);
            TextView heading=postAfterView.findViewById(R.id.headingPostLay1); heading.setText("heading"+i);
            TextView headDesc=postAfterView.findViewById(R.id.headingDescPostLay1); headDesc.setText("desc"+i);
            TextView postDesc=postAfterView.findViewById(R.id.postDescPostLay1);  postDesc.setText("postDesc"+i);
            postAfter.addView(postAfterView);
        }
    }
}
