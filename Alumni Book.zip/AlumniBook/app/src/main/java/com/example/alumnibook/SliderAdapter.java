package com.example.alumnibook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapter extends PagerAdapter {
    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapter(Context context) {
        this.context=context;
    }

    public int slide_images[]= { R.drawable.image0,R.drawable.ic_launcher_background_1,R.drawable.ic_launcher_background_3};
    public String[] slide_headings={ "I am not \nAnonymous","Buddy-Mates\nFellas","School We Go" };
    public String[] slide_description={ "Let your college know you. Your college\n may be in some" +
            " immediate need\n or due to some past interests want to know you.\nGet registered yourself and let your\n college find you.",
            "Get to know about your past friends. \nFriends from the school bear a taste of our\nchildhood. They integrate our school life.\n " +
                    "Register yourself for your well-wishers from the past.","Interact with your buddies,\n college deans and professors.\n" +
            "Experience group chats, personal updates and messaging.\nWelcome to AlumniBook!"
    };
    @Override
    public int getCount() {
        return slide_headings.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==(RelativeLayout) object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view=layoutInflater.inflate(R.layout.slide_layout,container,false);
        ImageView slideImage=view.findViewById(R.id.weImage);
        TextView slideHeading=view.findViewById(R.id.heading);
        TextView slideDescription=view.findViewById(R.id.description);

        slideImage.setImageResource(slide_images[position]);
        slideHeading.setText(slide_headings[position]);
        slideDescription.setText(slide_description[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout)object);
    }
}
