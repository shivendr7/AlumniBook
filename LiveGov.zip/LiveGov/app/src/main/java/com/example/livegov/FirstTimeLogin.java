package com.example.livegov;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.SignInButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;


//import org.jetbrains.annotations.NotNull;


public class FirstTimeLogin extends AppCompatActivity {

    private ViewPager mSlideViewPager;
    private LinearLayout mDotsLayout;
    private SliderAdapter sliderAdapter;
    private TextView mDots[];
    private SignInButton Register;

    private SignInButton signInButton;
    private GoogleSignInClient mGoogleSignInClient;
    private String TAG="FirstTimeLogin";
    private FirebaseAuth mAuth;
    private int RC_SIGN_IN=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_login);
        mSlideViewPager=findViewById(R.id.slideViewPager);
        mDotsLayout=findViewById(R.id.dotsLayout);
        Register=findViewById(R.id.RegisterButton);
        Register.setEnabled(false);


        sliderAdapter=new SliderAdapter(this);
        mSlideViewPager.setAdapter(sliderAdapter);

        googleSignIn();
        addDotsIndicator(0);
        mSlideViewPager.addOnPageChangeListener(viewListener);
    }
    public void addDotsIndicator(int pos) {
        mDots=new TextView[3];
        mDotsLayout.removeAllViews();
        for(int i=0;i<3;i++) {
            mDots[i]=new TextView(this);
            mDots[i].setText(Html.fromHtml("&#8226"));
            mDots[i].setTextSize(35);
            mDots[i].setTextColor(getResources().getColor(R.color.colorTransparentWhite));
            mDotsLayout.addView(mDots[i]);
        }
        mDots[pos].setTextColor(getResources().getColor(R.color.colorWhite));
    }
    ViewPager.OnPageChangeListener viewListener=new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
              addDotsIndicator(position);
              if(position==2) {
                  Register.setEnabled(true);
                  Register.animate().alpha(.7f).setDuration(1000);
              }

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    public void googleSignIn() {
        signInButton=findViewById(R.id.RegisterButton);
        mAuth =FirebaseAuth.getInstance();

        // Write a message to the database


        GoogleSignInOptions gso =new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).
                requestIdToken(getString(R.string.default_web_client_id)).requestEmail().build();
        mGoogleSignInClient= GoogleSignIn.getClient(this, gso);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
        /*button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGoogleSignInClient.signOut();
                Toast.makeText(FirstTimeLogin.this, "You are loged out", Toast.LENGTH_SHORT).show();
                button.setVisibility(View.INVISIBLE);
            }
        });*/
    }

    private void signIn(){
        Intent signInIntent= mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==RC_SIGN_IN){
            Task<GoogleSignInAccount> task=GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask){
        try {
            GoogleSignInAccount acc = completedTask.getResult(ApiException.class);
            FirebaseGoogleAuth(acc);
        }catch (ApiException e){
            Toast.makeText(this, "An error occurred", Toast.LENGTH_SHORT).show();
            FirebaseGoogleAuth(null);
        }
    }
    private void FirebaseGoogleAuth(GoogleSignInAccount acct ){
        AuthCredential authCredential  = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(authCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>(){
            @Override
            public void onComplete (@NonNull Task < AuthResult > task) {
                if (task.isSuccessful()) {
                    Toast.makeText(FirstTimeLogin.this, "SignIn Successful", Toast.LENGTH_SHORT).show();
                    FirebaseUser user = mAuth.getCurrentUser();
                    updateUI(user);
                } else {
                    Toast.makeText(FirstTimeLogin.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                    updateUI(null);
                }
            }
        });
    }
    private void updateUI( FirebaseUser fUser){
        //button.setVisibility(View.VISIBLE);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if(account!= null){
            final String personName=account.getDisplayName();
            String personGivenName = account.getGivenName();
            String personFamilyName= account.getFamilyName();
            String personalEmail= account.getEmail();
            String personId =account.getId();
            Uri personPhoto= account.getPhotoUrl();
            HashMap<String,Object> user=new HashMap<>();
            LiveGovUser user2=new LiveGovUser(personName);
            user.put("id",personId);
            user.put("Info",user2);
           // FirebaseDatabase.getInstance().getReference().child("IDs").child(fUser.getUid()).setValue(user);
            ValueEventListener postListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI
                    if(dataSnapshot.child("Info").child("OBJ").child("tagLine").getValue()==null)
                    { Intent in=new Intent(FirstTimeLogin.this,NewAccountCreation1.class);
                         in.putExtra("name",personName); startActivity(in);
                        Toast.makeText(FirstTimeLogin.this, "You will require a new Account", Toast.LENGTH_SHORT).show(); }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Getting Post failed, log a message
                }
            };
            FirebaseDatabase.getInstance().getReference().child("IDs").child(fUser.getUid()).addListenerForSingleValueEvent(postListener);
            finish();
           // FirebaseDatabase.getInstance().getReference().child("IDs").child(fUser.getUid()).removeEventListener(postListener);
        }
    }
}




