package com.example.livegov;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.widgets.Snapshot;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.transition.ChangeBounds;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Comment;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    public static final int CAMERA_REQUEST=9999;
    private ConstraintLayout layout;
    private ConstraintSet set0=new ConstraintSet();
    private ConstraintSet set1=new ConstraintSet();
    private ConstraintSet set4=new ConstraintSet();
    private ConstraintSet set3=new ConstraintSet();
    final long ONE_MEGABYTE=1024*1024;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        


        if (user == null) { Intent in=new Intent(this,FirstTimeLogin.class);
            startActivity(in);
        }
        else {  Toast.makeText(this, "Welcome "+user.getDisplayName(), Toast.LENGTH_SHORT).show();
            ValueEventListener postListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI
                    if(dataSnapshot.child("Info").child("OBJ").child("tagLine").getValue()!=null)
                    {   inflation();
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Getting Post failed, log a message
                }
            };
            FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().
                    getUid()).addListenerForSingleValueEvent(postListener);
        }




        //inflation();
        SetInfoLayout=false;
        setBlueIcon('H');
        layout=findViewById(R.id.layout);
        set0.clone(layout);
        set1.clone(this,R.layout.menu_layout1);
        set3.clone(this,R.layout.portal_layout3);
        set4.clone(this,R.layout.portal_layout4);
        menuO=0;
        layout.setOnTouchListener(new OnSwipeTouchListener(MainActivity.this){
            public void onSwipeTop() { }

            public void onSwipeRight() { try { Intent in=new Intent(); in.setAction(MediaStore.ACTION_IMAGE_CAPTURE); startActivityForResult(in,CAMERA_REQUEST); }
            catch(Exception e) {e.printStackTrace();} }
            public void onSwipeLeft() {
                if(menuO==1) { menuO=0; applyHome(); }
            }
            public void onSwipeBottom() { }
        });
        ImageView im=findViewById(R.id.srchIcon);
        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in= new Intent(MainActivity.this,NewAccountCreation1.class); startActivity(in);
            }
        });
    }
    private int menuO;
    public void applySet1() { menuO=1;  TransitionManager.beginDelayedTransition(layout); set1.applyTo((layout)); }
    public void applyHome() {  TransitionManager.beginDelayedTransition(layout); set0.applyTo((layout)); }
    public void applySet4() { Transition cB=new ChangeBounds(); cB.setInterpolator(new OvershootInterpolator()); TransitionManager.beginDelayedTransition(layout,cB); set4.applyTo((layout)); }
    public void applySet3() { TransitionManager.beginDelayedTransition(layout); set3.applyTo((layout)); }

    public void menuOn(View v) {
        applySet1(); FirebaseAuth.getInstance().signOut(); finish();
           }
    public void homeOn(View v) { applyHome();setBlueIcon('H');
    ProgressBar im=findViewById(R.id.idImgProgressBar); im.setVisibility(View.INVISIBLE);
    }
    public void peopleOn(View v) {  setBlueIcon('P'); Intent in=new Intent(this,CommunityActivity1.class); startActivity(in); }


    boolean SetInfoLayout;
    public void accInfoOn(View vi) { setBlueIcon('I'); applySet3();
        if(SetInfoLayout) return;
        LayoutInflater inf=getLayoutInflater();
        final LinearLayout infoLay=findViewById(R.id.infoLinearLayout6);
        View v=inf.inflate(R.layout.profile_lay1,null);
        final TextView t1=v.findViewById(R.id.idProfileName6);
        final TextView t2=v.findViewById(R.id.idProfileInfoTxt6);
        final TextView t3=v.findViewById(R.id.idInfoTxt6);
        final ImageView profileImg=v.findViewById(R.id.idProfileImg6);
        final ImageView bgImage=v.findViewById(R.id.idBackgroundImg6);
        StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info");

        ref.child("profileImage").child("profilePic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                profileImg.setImageBitmap(Bitmap.createScaledBitmap(bmp,profileImg.getWidth(),profileImg.getHeight(),false));

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) { }});

        ref.child("BgImage").child("backgroundPic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                bgImage.setImageBitmap(Bitmap.createScaledBitmap(bmp,bgImage.getWidth(),bgImage.getHeight(),false));
                if(bgImage.getDrawable()!=null) { ProgressBar p=findViewById(R.id.bgImageProgressBar); p.setVisibility(View.INVISIBLE); }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(MainActivity.this, "Image loading Failed", Toast.LENGTH_SHORT).show();
                ProgressBar p=findViewById(R.id.bgImageProgressBar); p.setVisibility(View.INVISIBLE);
            }});


        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).
                addListenerForSingleValueEvent(new ValueEventListener() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        LiveGovUser user= dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                        assert user != null;
                        t1.setText(user.getUserName());
                        t2.setText(user.getTagLine());
                        t3.setText("Relationship status:"+user.getRelationshipStatus()+"\nJob:"+user.getOccupation()+"\nLive In:"+user.getLiveIn()+
                                "\nWork In:"+user.getWorkIn()+"\nHobbies:"+user.getHobbies()+"\nLikes:"+user.getLikes());
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }});



        infoLay.addView(v);
        v=inf.inflate(R.layout.write_smth_lay1,null);
        final ImageView writeSmthIdIcon=v.findViewById(R.id.id_img_icon2);
        ref.child("profileImage").child("profilePic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                writeSmthIdIcon.setImageBitmap(Bitmap.createScaledBitmap(bmp,writeSmthIdIcon.getWidth(),writeSmthIdIcon.getHeight(),false));
                if(writeSmthIdIcon.getDrawable()!=null) { ProgressBar p=findViewById(R.id.id_icon_progressBar2); p.setVisibility(View.INVISIBLE); }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) { }});

        infoLay.addView(v);

        final int[] l = {1};
        ChildEventListener childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
              //  String s=dataSnapshot.getKey().getValue();
                Toast.makeText(MainActivity.this, dataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
          //      ArrayList<String> ar= dataSnapshot.child("OBJ").child("postDetails").getValue(ArrayList<String>.class);
              //  Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
                LayoutInflater inf= getLayoutInflater();
                View v=inf.inflate(R.layout.post_layout1,null);
                final ImageView img=v.findViewById(R.id.postPostLay1);
                TextView hd=v.findViewById(R.id.headingPostLay1);
               TextView hdD=v.findViewById(R.id.headingDescPostLay1);
                TextView pD=v.findViewById(R.id.postDescPostLay1);
            /*        StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Posts");
              //  Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
                   ref.child(s.substring(0,s.indexOf('$'))).child("postPic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                            img.setImageBitmap(Bitmap.createScaledBitmap(bmp,img.getWidth(),img.getHeight(),false));

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) { }}); */

           //         hd.setText(s.substring(s.indexOf('$')+1,s.indexOf('%')) );
             //   hdD.setText(s.substring(s.indexOf('%')+1,s.indexOf('*')) );
            //    pD.setText(s.substring(s.indexOf('*')+1));


                infoLay.addView(v);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {}

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {}

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info").
    child("OBJ").child("postDetails").addChildEventListener(childEventListener);



        v=inf.inflate(R.layout.post_layout1,null); infoLay.addView(v);


         SetInfoLayout=true;
    }
    public void notiOn(View v) { setBlueIcon('N'); applySet4(); }
    public void setBlueIcon(char ch) {
        ImageView home=findViewById(R.id.homIcon1);  home.setBackgroundResource(R.drawable.icon_circle_shape);
        ImageView friends=findViewById(R.id.connIcon1); friends.setBackgroundResource(R.drawable.icon_circle_shape);
        ImageView info=findViewById(R.id.accIcon1);  info.setBackgroundResource(R.drawable.icon_circle_shape);
        ImageView noti=findViewById(R.id.notiIcon1);  noti.setBackgroundResource(R.drawable.icon_circle_shape);
        switch(ch) {
            case 'P':  friends.setBackgroundResource(R.drawable.icon_circle_shape_blue); break;
            case 'H':  home.setBackgroundResource(R.drawable.icon_circle_shape_blue); break;
            case 'I':  info.setBackgroundResource(R.drawable.icon_circle_shape_blue); break;
            case 'N':  noti.setBackgroundResource(R.drawable.icon_circle_shape_blue); break;
            default: break;
        }
    }

   public void inflation() {

        final ImageView imageView=findViewById(R.id.UserIcon1);
       StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info");

       ref.child("profileImage").child("profilePic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
           @Override
           public void onSuccess(byte[] bytes) {
               Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
               imageView.setImageBitmap(Bitmap.createScaledBitmap(bmp,imageView.getWidth(),imageView.getHeight(),false));
               if(imageView.getDrawable()!=null)
               {  ProgressBar idImgPb=findViewById(R.id.idImgProgressBar); idImgPb.setVisibility(View.INVISIBLE);  }
           }
       }).addOnFailureListener(new OnFailureListener() {
           @Override
           public void onFailure(@NonNull Exception exception) { }});

        LinearLayout Horiz1=findViewById(R.id.linHorizScroll1);
       final LayoutInflater inf=getLayoutInflater();
        Horiz1.removeAllViews();

        for(int i=0;i<11;i++) {
            View NoticeView1=inf.inflate(R.layout.noitice_layout1,null);
            TextView txt=NoticeView1.findViewById(R.id.txtViewNoticeLay1);
            txt.setText("Clg"+(i+1));
            Horiz1.addView(NoticeView1);
        }

        ImageView dropDown;
        LinearLayout postBtw=findViewById(R.id.linPostBetw1), postAfter=findViewById(R.id.linPostAfter1);
        postBtw.removeAllViews(); postAfter.removeAllViews();
        View postBtwView=inf.inflate(R.layout.post_layout1,null);
        dropDown=postBtwView.findViewById(R.id.dropdownPostLay1);
        dropDownOpen(dropDown);
        postBtw.addView(postBtwView);
        for(int i=2;i<12;i++) {
            View postAfterView=inf.inflate(R.layout.post_layout1,null);
            TextView heading=postAfterView.findViewById(R.id.headingPostLay1); heading.setText("heading"+i);
            TextView headDesc=postAfterView.findViewById(R.id.headingDescPostLay1); headDesc.setText("desc"+i);
            TextView postDesc=postAfterView.findViewById(R.id.postDescPostLay1);  postDesc.setText("postDesc"+i);
            dropDown=postAfterView.findViewById(R.id.dropdownPostLay1); dropDownOpen(dropDown);
            dropDown=postAfterView.findViewById(R.id.likePostLay1); bottomPopUpOpen(dropDown);
            postAfter.addView(postAfterView);
        }
        final LinearLayout Sugg1=findViewById(R.id.linHorizScroll2);


            ChildEventListener childEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {

                    if(!dataSnapshot.getKey().equals(FirebaseAuth.getInstance().getCurrentUser().getUid()))
                    {  View suggView=inf.inflate(R.layout.suggestion_lay1,null);
                       final ImageView icon=suggView.findViewById(R.id.imgSuggView);
                       TextView name=suggView.findViewById(R.id.nameTextSugg);
                       TextView desc=suggView.findViewById(R.id.descTextSugg);
                        StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(dataSnapshot.getKey()).child("Info");

                        ref.child("profileImage").child("profilePic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                            @Override
                            public void onSuccess(byte[] bytes) {
                                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                                icon.setImageBitmap(Bitmap.createScaledBitmap(bmp,icon.getWidth(),icon.getHeight(),false));

                            }
                        }).addOnFailureListener(new OnFailureListener() {

                            @Override
                            public void onFailure(@NonNull Exception exception) { }});
                        LiveGovUser user=dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                        name.setText(user.getUserName() );
                        desc.setText( user.getTagLine());

                        Sugg1.addView(suggView);
                    }
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {}

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {}

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {}

                @Override
                public void onCancelled(DatabaseError databaseError) {}
            };
            FirebaseDatabase.getInstance().getReference().child("IDs").addChildEventListener(childEventListener);


        LinearLayout notiLay=findViewById(R.id.notiLinearLayout1);
        for(int i=0;i<15;i++) {
            View v=inf.inflate(R.layout.noti_lay1,null);
            notiLay.addView(v); }

      /* final LiveGovUser[] user = new LiveGovUser[1];
        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                       user[0] = dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
        LinearLayout infoLay=findViewById(R.id.infoLinearLayout6);
        View v=inf.inflate(R.layout.profile_lay1,null);
        TextView t=v.findViewById(R.id.idProfileName6);
        t.setText(user[0].getUserName());

        infoLay.addView(v);
        v=inf.inflate(R.layout.write_smth_lay1,null); infoLay.addView(v);
        for(int i=0;i<10;i++) { v=inf.inflate(R.layout.post_layout1,null); infoLay.addView(v); }*/

    }
    public void dropDownOpen(View v) {
        v.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                applySet1();
            }
        });
    }
    public void bottomPopUpOpen(View v) {
        final LayoutInflater inf=getLayoutInflater();
        v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                LinearLayout botPop=findViewById(R.id.belowPopup);
                View postReact=inf.inflate(R.layout.post_reaction_lay1,null);
                botPop.addView(postReact);
                return false;
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        ImageView imageView=findViewById(R.id.UserIcon1);
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CAMERA_REQUEST) {
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            imageView.setImageBitmap(bitmap);
        }
    }
    public void openPostCreation(View v) {
        Intent in=new Intent(this,PostCreation1.class);
        startActivity(in);
    }
}
