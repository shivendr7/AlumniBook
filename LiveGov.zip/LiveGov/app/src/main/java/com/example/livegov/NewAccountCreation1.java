package com.example.livegov;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.transition.TransitionManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;

public class NewAccountCreation1 extends AppCompatActivity {
    private static final int PERMISSION_CODE =1000 ;
    private static final int REQUEST_GALLERY_IMAGE1 = 14;
    private ConstraintLayout layout;
    private ConstraintSet set0=new ConstraintSet();
    private ConstraintSet set1=new ConstraintSet();
    public String img;


    private static final int PICK_IMAGE=1;
    Uri ImageUri;
    private ImageView profileImg;
    private ImageView bgImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account_creation1);
        Act1();
        layout=findViewById(R.id.Layout2);
        set0.clone(layout);
        AutoCompleteTextView Name=findViewById(R.id.nameTextView0);
        Name.setText(getIntent().getExtras().getString("name"));
        set1.clone(this,R.layout.activity_new_account_creation2);
        TextView t1=findViewById(R.id.ch100);
        profileImg=findViewById(R.id.profileImgView0);
        bgImage=findViewById(R.id.profileBackgroundImg0);
       /* t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gal=new Intent();
                gal.setType("Img/*");
                gal.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gal,"Select Picture"),PICK_IMAGE);
            }
        }); */
        AutoCompleting();

    }
    public void applyHome() {  TransitionManager.beginDelayedTransition(layout); set0.applyTo((layout)); }
    public void applyset1() {  TransitionManager.beginDelayedTransition(layout); set1.applyTo((layout)); }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==REQUEST_GALLERY_IMAGE1&&resultCode==RESULT_OK) {
            try {
                final Uri imguri=data.getData();
                InputStream imageStream=getContentResolver().openInputStream(imguri);
                final Bitmap selImg= BitmapFactory.decodeStream(imageStream);
                if(img.equals("profile"))
                profileImg.setImageBitmap(selImg);
                else bgImage.setImageBitmap(selImg);
            } catch(Exception e) { e.printStackTrace();}
        }

    }
    public void Act1() {
       final int a[]={R.id.Ac101,R.id.Ag101,R.id.Rel101,R.id.Oc101,R.id.Liv101,R.id.wrk101,R.id.Hob101,R.id.Lik101};
       final int b[]={R.id.accountInfoTextView0,R.id.ageTextView0,R.id.msTextView0,R.id.occupationTextView0,R.id.liTextView0,R.id.workInTextView0,R.id.hobbiesTextView0,R.id.likesTextView0};
       final String txt[]={"Some Tagline/Quote for your Wall","Only for Better Understanding","Just to address you better","Helps people to know you","Necessary for better posting","For better performance","Just some data about you","Just some data about you"};
        final TextView hintGuide=findViewById(R.id.hintTxt0);
       for(int i=0;i<a.length;i++) {
           EditText t=findViewById(b[i]);

           t.setOnTouchListener(new View.OnTouchListener() {
               @Override
               public boolean onTouch(View v, MotionEvent event) {
                   int i=0;
                   while(v.getId()!=b[i]) i++;
                   TextView t=findViewById(a[i]);
                   hintGuide.setText(txt[i]);
                   t.animate().alpha(1).setDuration(2000);
                   return false;
               }
           });

       }
    }
    public void AutoCompleting() {
       String[] LOCALITIES= new String[]{"laxmipuram","kashimbazar","palamnagar","vadnagar","lakhimpur","paramdwip"};


        AutoCompleteTextView editText= findViewById(R.id.liTextView0);
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,LOCALITIES);
        editText.setAdapter(adapter);
    }
    public void create(View v) {

        AutoCompleteTextView Name=findViewById(R.id.nameTextView0); LiveGovUser user=new LiveGovUser(Name.getText().toString());
        AutoCompleteTextView TagL=findViewById(R.id.accountInfoTextView0); user.setTagLine(TagL.getText().toString());
        AutoCompleteTextView Age=findViewById(R.id.ageTextView0); try {user.setAge(Integer.parseInt(Age.getText().toString()));} catch(Exception e) { Toast.makeText(this, "Invalid Age!", Toast.LENGTH_SHORT).show(); }
        AutoCompleteTextView relS=findViewById(R.id.msTextView0);  user.setRelationshipStatus(relS.getText().toString());
        AutoCompleteTextView occ=findViewById(R.id.occupationTextView0); user.setOccupation(occ.getText().toString());
        AutoCompleteTextView livI=findViewById(R.id.liTextView0); user.setLivesIn(livI.getText().toString());
        AutoCompleteTextView wrkI=findViewById(R.id.workInTextView0); user.setWorksIn(wrkI.getText().toString());
        AutoCompleteTextView hob=findViewById(R.id.hobbiesTextView0); user.setHobbies(hob.getText().toString());
        AutoCompleteTextView lik=findViewById(R.id.likesTextView0); user.setLikes(lik.getText().toString());
        uploadImage(profileImg,"profile");
       uploadImage(bgImage,"background");
        HashMap<String,Object> info=new HashMap<>();
        //info.put("UserName",user.getUserName());
        //info.put("TagLine",user.getTagLine());
        //info.put("Age",user.getAge());
        //info.put("Relationship Status",user.getRelationshipStatus());
        //info.put("Occupation",user.getOccupation());
        //info.put("Lives In",user.getLiveIn());
        //info.put("Works In",user.getWorkIn());
        //info.put("Hobbies",user.getHobbies());
        //info.put("Likes",user.getLikes());
        info.put("OBJ",user);
        info.put("TagLine","Val");
        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info").setValue(info);
        finish();
    }
    public void uploadImage(ImageView imageView,String img)
    {
        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache();
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();
        StorageReference correctBranch=FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info");
        UploadTask upload;
        if(img.equals("profile")) {
             upload=correctBranch.child("profileImage").child("profilePic.jpg").putBytes(data);
        } else {
             upload=correctBranch.child("BgImage").child("backgroundPic.jpg").putBytes(data);
        }
        upload.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(NewAccountCreation1.this, "Failure in uploading Images", Toast.LENGTH_SHORT).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                // ...
            }
        });
    }

    public void importProfilePic(View v) {
        img="profile";
        PickImage();
    }
    public void importBackgroundImg(View v) {
        img="background";
        PickImage();
    }
    public void PickImage(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                String permissions[] = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
                requestPermissions(permissions, PERMISSION_CODE);
            } else {
                pickImageFromGallery1();
            }
        } else {
            pickImageFromGallery1();
        }
    }
    public void pickImageFromGallery1() {
        Intent in=new Intent(Intent.ACTION_PICK);
        in.setType("image/*");
        startActivityForResult(in,REQUEST_GALLERY_IMAGE1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode) {
            case PERMISSION_CODE: {
                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                    pickImageFromGallery1();
                } else {
                    Toast.makeText(this, "You need to Set an Image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }



    @Override
    public void onBackPressed() {
        FirebaseAuth.getInstance().signOut(); finish();
    }
}
