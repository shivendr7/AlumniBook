package com.example.livegov;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Layout;
import android.transition.TransitionManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PostCreation1 extends AppCompatActivity {
    private static final int PERMISSION_CODE =1000 ;
    private static final int REQUEST_GALLERY_IMAGE1 = 14;
    public static final int CAMERA_REQUEST=9999;
    ConstraintLayout layout;
    ConstraintSet set0=new ConstraintSet();
    ConstraintSet set1=new ConstraintSet();
    int tag;
    ImageView PostImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_creation1);
        EditText E=findViewById(R.id.editText01);
        PostImage=findViewById(R.id.imageView01);
        E.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                TextView t=findViewById(R.id.hintTxtPostCreation0);
                t.setText("Write description of the post");
                return false;
            }
        });
        tag=1;
        E=findViewById(R.id.postHeadEditText01);
        E.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                TextView t=findViewById(R.id.hintTxtPostCreation0);
                t.setText("Headings for the post");
                return false;
            }
        });
        E=findViewById(R.id.postDescriptionEditText01);
        E.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                TextView t=findViewById(R.id.hintTxtPostCreation0);
                t.setText("Descriptions for the post");
                return false;
            }
        });
        layout=findViewById(R.id.Layout01);
        set0.clone(layout);
        set1.clone(this,R.layout.activity_post_creation2);
        ArrayList<String> aL=new ArrayList<>();

        for(char ch='a';ch<='z';ch++)
        aL.add(ch+"9");

        ArrayAdapter<String> aa=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,aL);
        ListView listView=findViewById(R.id.TagList01);
        listView.setAdapter(aa);
    }

    public void applyHome() {  TransitionManager.beginDelayedTransition(layout); set0.applyTo((layout)); }
    public void applySet1() {  TransitionManager.beginDelayedTransition(layout); set1.applyTo((layout)); }


    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==REQUEST_GALLERY_IMAGE1&&resultCode==RESULT_OK) {
            try {
                final Uri imguri=data.getData();
                InputStream imageStream=getContentResolver().openInputStream(imguri);
                final Bitmap selImg= BitmapFactory.decodeStream(imageStream);
                PostImage.setImageBitmap(selImg);

            } catch(Exception e) { e.printStackTrace();}
        }
        if(requestCode==CAMERA_REQUEST) {
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            PostImage.setImageBitmap(bitmap);
        }

    }
    public void selectImage(View v) {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                String permissions[] = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
                requestPermissions(permissions, PERMISSION_CODE);
            } else {
                pickImageFromGallery1();
            }
        } else {
            pickImageFromGallery1();
        }
    }
    public void pickImageFromGallery1() {
        Intent in=new Intent(Intent.ACTION_PICK);
        in.setType("image/*");
        startActivityForResult(in,REQUEST_GALLERY_IMAGE1);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode) {
            case PERMISSION_CODE: {
                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                    pickImageFromGallery1();
                } else {
                    Toast.makeText(this, "You need to Set an Image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    public void Camera(View v) {
        try { Intent in=new Intent(); in.setAction(MediaStore.ACTION_IMAGE_CAPTURE); startActivityForResult(in,CAMERA_REQUEST); }
        catch(Exception e) {e.printStackTrace();}
    }
    public void OpenTags(View v) {
        if(tag==0)
        { applyHome(); tag=1; }
        else { applySet1(); tag=0; }

    }

    @Override
    public void onBackPressed() {
        if(tag==0) { tag=1;  applyHome(); }
         else finish();
    }

    public  void  create1(View v){

                final LiveGovPost Community= new LiveGovPost();
        EditText heading= findViewById(R.id.postHeadEditText01); Community.setHeading(heading.getText().toString());
        EditText description =findViewById(R.id.postDescriptionEditText01);Community.setDescripton(description.getText().toString());
        EditText experience = findViewById(R.id.editText01);Community.setExperience(experience.getText().toString());
       // mDatabase.child("Community").child("OBJ").setValue(Community);
        final ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
            LiveGovUser user=dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                user.addPosts(UUID.randomUUID().toString()+"$"+Community.getHeading()+"%"+Community.getDescripton()+"*"+Community.getExperience());

                //Toast.makeText(PostCreation1.this, user.toString(), Toast.LENGTH_SHORT).show();
                HashMap<String,Object> info=new HashMap<>();
                info.put("OBJ",user);
                info.put("TagLine","Val");
                FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info").setValue(info);
               // FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info").
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
            }
        };
        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(postListener);

        ImageView imageView=findViewById(R.id.imageView01);
        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache();
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();
        final String[] s = new String[1];
        final ValueEventListener postListener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LiveGovUser user=dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                ArrayList<String> posts=user.getPosts(); int len= posts.size(); s[0] =getUid(posts.get(len-1));
                }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
            }
        };
        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(postListener1);

        StorageReference correctBranch= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Posts").child(String.valueOf(s));
        UploadTask upload;

            upload=correctBranch.child("PostImg").child("postPic.jpg").putBytes(data);

        upload.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(PostCreation1.this, "Failure in uploading Images", Toast.LENGTH_SHORT).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                // ...
            }
        });
        Toast.makeText(this, "Posted", Toast.LENGTH_SHORT).show();
        finish();

        //childUpdates.put("/Community/" + key, Community);
       // childUpdates.put("/user-posts/" + userId + "/" + key, postValues);

        //mDatabase.updateChildren(childUpdates);
    }

  public String getUid(String s) { return(s.substring(0,s.indexOf('$')));   }

}
