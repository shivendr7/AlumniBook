package com.example.livegov;

import android.media.Image;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.HashMap;

public class LiveGovUser {
    public String userName;
    public String tagLine;
    public int age;
    public String relationshipStatus;
    public String occupation;
    public String liveIn;
    public String workIn;
    public String likes;
    public String hobbies;
    public ArrayList<String> postDetails=new ArrayList<>();

    public LiveGovUser() {}
    public LiveGovUser(String username) {
        this.userName=username;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public void setTagLine(String tagline) { this.tagLine=tagline;  }
    public void setRelationshipStatus(String relationshipstatus) { this.relationshipStatus=relationshipstatus;  }
    public void setOccupation(String occupation) { this.occupation=occupation;  }
    public void setLivesIn(String livein) { this.liveIn=livein; }
    public void setWorksIn(String workin) { this.workIn=workin;  }
    public void setLikes(String likes) { this.likes=likes;  }
    public void setHobbies(String hobbies) { this.hobbies=hobbies;  }
    public void addPosts(String post) { this.postDetails.add(post); }


    public String getUserName() {
        return userName;
    }

    public int getAge() { return age; }

    public String getTagLine() {
        return tagLine;
    }

    public String getRelationshipStatus() {
        return relationshipStatus;
    }

    public String getOccupation() {
        return occupation;
    }

    public String getLiveIn() {
        return liveIn;
    }

    public String getWorkIn() {
        return workIn;
    }

    public String getLikes() {
        return likes;
    }

    public String getHobbies() {
        return hobbies;
    }
public ArrayList<String> getPosts( ) { return postDetails; }

}
