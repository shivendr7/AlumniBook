package com.example.livegov;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapter extends PagerAdapter {
    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapter(Context context) {
        this.context=context;
    }

    public int slide_images[]= { R.drawable.first_intro_img,R.drawable.second_intro_img,R.drawable.third_intro_img  };
    public String[] slide_headings={ "I am Aware \nBuddy","Participate\nActively","Live-Gov we come!" };
    public String[] slide_description={ "Unified Mobile Application for new-age Governance." ,
            "Citizen participation in governance by providing \nan avenue for channelizing their issues, comments & suggestions\n"+
            "to elected representatives & associated organisations.","Be an active partner in nation building. Participate in \n Communities, Events,Discussion & create posts.\n Contribute now. "
    };
    @Override
    public int getCount() {
        return slide_headings.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==(RelativeLayout) object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view=layoutInflater.inflate(R.layout.slide_layout,container,false);
        ImageView slideImage=view.findViewById(R.id.weImage);
        TextView slideHeading=view.findViewById(R.id.heading);
        TextView slideDescription=view.findViewById(R.id.description);

        slideImage.setImageResource(slide_images[position]);
        slideHeading.setText(slide_headings[position]);
        slideDescription.setText(slide_description[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout)object);
    }
}
