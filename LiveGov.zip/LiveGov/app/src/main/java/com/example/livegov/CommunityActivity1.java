package com.example.livegov;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class CommunityActivity1 extends AppCompatActivity {
    private ConstraintLayout lay;
    private ConstraintSet set0=new ConstraintSet();
    private ConstraintSet set1=new ConstraintSet();
    private ConstraintSet set2=new ConstraintSet();
    private ConstraintSet set3=new ConstraintSet();
    private ConstraintSet set4=new ConstraintSet();
    private ConstraintSet set5=new ConstraintSet();

    final long ONE_MEGABYTE=1024*1024;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community1);
        setBlue('H');
        inflation();
        lay=findViewById(R.id.Layout2);
        set0.clone(lay);
        set1.clone(this,R.layout.community_events2);
        set2.clone(this,R.layout.community_review3);
        set3.clone(this,R.layout.community_about4);
        set4.clone(this,R.layout.community_posts5);
        set5.clone(this,R.layout.community_members6);
        //pushData();

    }

    public void applySet1() {   TransitionManager.beginDelayedTransition(lay);  set1.applyTo((lay)); }
    public void applyHome() {TransitionManager.beginDelayedTransition(lay); set0.applyTo((lay)); }
    public void applySet2() {   TransitionManager.beginDelayedTransition(lay); set2.applyTo((lay)); }
    public void applySet3() {   TransitionManager.beginDelayedTransition(lay); set3.applyTo((lay)); }
    public void applySet4() {   TransitionManager.beginDelayedTransition(lay); set4.applyTo((lay)); }
    public void applySet5() {   TransitionManager.beginDelayedTransition(lay); set5.applyTo((lay)); }

    public void inflation() {
        LinearLayout homeLay=findViewById(R.id.homeVertLay1);
        LayoutInflater inf=getLayoutInflater();
        homeLay.removeAllViews();

        StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info");
        View ve=inf.inflate(R.layout.write_smth_lay1,null);
        final ImageView writeSmthIdIcon=ve.findViewById(R.id.id_img_icon2);
        ref.child("profileImage").child("profilePic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                writeSmthIdIcon.setImageBitmap(Bitmap.createScaledBitmap(bmp,writeSmthIdIcon.getWidth(),writeSmthIdIcon.getHeight(),false));
                if(writeSmthIdIcon.getDrawable()!=null) { ProgressBar p=findViewById(R.id.id_icon_progressBar2); p.setVisibility(View.INVISIBLE); }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) { }});
        homeLay.addView(ve);
        int layouts[]={R.layout.recommend_pge_lay,R.layout.community_about_lay1,R.layout.page_transparency_lay1,R.layout.create_page_lay1
                ,R.layout.community_strategy1,R.layout.related_community_lay1,R.layout.related_community_lay1,R.layout.post_layout1,R.layout.post_layout1};
        for(int i=0;i<layouts.length;i++) {
            View v=inf.inflate(layouts[i],null);
            homeLay.addView(v);


        }
        LinearLayout eventUpcoming=findViewById(R.id.upcomingEventsLay1),eventPast=findViewById(R.id.pastEventsLay1);
        for(int i=0;i<7;i++) {
            View v=inf.inflate(R.layout.event_lay2,null);
            if(i>2) eventPast.addView(v); else eventUpcoming.addView(v);
        }
        LinearLayout reviewLay=findViewById(R.id.communityReviewLinearLayout4);
        View v=inf.inflate(R.layout.recommend_pge_lay,null);
        reviewLay.addView(v); v=inf.inflate(R.layout.community_review_lay1,null);
        reviewLay.addView(v);

        LinearLayout aboutLay1=findViewById(R.id.communityAboutLinearLay4);
        v=inf.inflate(R.layout.community_strategy1,null); aboutLay1.addView(v);
        v=inf.inflate(R.layout.community_about_lay1,null); aboutLay1.addView(v);

        LinearLayout postsLay1=findViewById(R.id.communityPostLinearLay5);
        for(int i=0;i<9;i++) {
            v=inf.inflate(R.layout.post_layout1,null); postsLay1.addView(v); }

        LinearLayout memberLay1=findViewById(R.id.communityMembersLinearLay6);
        for(int i=0;i<15;i++) {
            v=inf.inflate(R.layout.member_lay1,null); memberLay1.addView(v); }
    }
    public void setBlue(char ch) {
        TextView home=findViewById(R.id.communityHome1); home.setBackgroundResource(R.drawable.id_img_shape);
        TextView event=findViewById(R.id.communityEvents1); event.setBackgroundResource(R.drawable.id_img_shape);
        TextView review=findViewById(R.id.communityReviews1); review.setBackgroundResource(R.drawable.id_img_shape);
        TextView about=findViewById(R.id.communityAbout1); about.setBackgroundResource(R.drawable.id_img_shape);
        TextView post=findViewById(R.id.communityPosts1); post.setBackgroundResource(R.drawable.id_img_shape);
        TextView member=findViewById(R.id.communityGuys1); member.setBackgroundResource(R.drawable.id_img_shape);
        switch(ch) {
            case 'H':  home.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            case 'E':  event.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            case 'R':  review.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            case 'A':  about.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            case 'P':  post.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            case 'M':  member.setBackgroundResource(R.drawable.id_img_shape_blue); break;
            default: break;
        }


    }
    public void homeOn2(View v) { setBlue('H'); applyHome(); }
    public void eventsOn2(View v) {setBlue('E'); applySet1();  }
    public void reviewsOn2(View v) {setBlue('R'); applySet2(); }
    public void aboutOn2(View v) {setBlue('A'); applySet3(); }
    public void postsOn2(View v) {setBlue('P'); applySet4(); }
    public void membersOn2(View v) {setBlue('M'); applySet5(); }

     public void pushData(){
        final TextView communityTitle= findViewById(R.id.communityTitle1);
        final TextView communityDesc=findViewById(R.id.communityDesc1);
        final TextView communityRegion =findViewById(R.id.communityRegion1);
        final ImageView communityProfileImg= findViewById(R.id.communityProfileImg1);
        final ImageView communityBackground= findViewById(R.id.communityWallpaper1);

        StorageReference ref= FirebaseStorage.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Info");

        ref.child("BgImage").child("backgroundPic.jpg").getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                communityBackground.setImageBitmap(Bitmap.createScaledBitmap(bmp,communityBackground.getWidth(),communityBackground.getHeight(),false));
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) { }});

        FirebaseDatabase.getInstance().getReference().child("IDs").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).
                addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        LiveGovUser user= dataSnapshot.child("Info").child("OBJ").getValue(LiveGovUser.class);
                        communityTitle.setText(user.getUserName());
                        communityDesc.setText(user.getTagLine());
                        communityRegion.setText(user.getRelationshipStatus());
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }});
    }

}