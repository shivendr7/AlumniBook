package com.example.livegov;

import java.util.ArrayList;


public class LiveGovPost {
        public String Descripton;
        public String Heading;
        public ArrayList<String> Comments;
        public String Experience;
        public int Upvotes;
        public int CriticalMarks;
        public int Likes;
        public String Privacy;

        public  void  setDescripton(String Description){this.Descripton=Description; }
        public  void setHeading(String Heading ){this.Heading=Heading;}

        public void setLikes(int likes) {
            this.Likes = likes;
        }

        public void setCriticalMarks(int CriticalMarks) {
            this.CriticalMarks=CriticalMarks;
        }

        public void setUpvotes(int upvotes){Upvotes=upvotes;}
        public void addComment(String Comment){ this.Comments.add(Comment); }
        public void setPrivacy(String Privacy){this.Privacy=Privacy;}
        public  void setExperience( String Experience){this.Experience=Experience;}

        public int getCriticalMarks() {
            return CriticalMarks;
        }

        public int getLikes() {
            return Likes;
        }

        public ArrayList<String> getComments() {
            return Comments;
        }

        public int getUpvotes() {
            return Upvotes;
        }

        public String getDescripton() {
            return Descripton;
        }

        public String getHeading() {
            return Heading;
        }

        public String getPrivacy() {
            return Privacy;
        }

    public String getExperience() {
        return Experience;
    }
}
